using System.ComponentModel.DataAnnotations;

namespace BookManagement.Models;

public class Book
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Không được để trống")]
    public string Name { get; set; } = string.Empty;

    [Range(0.01, double.MaxValue, ErrorMessage = "Giá phải lớn hơn 0")]
    public double Price { get; set; }
}
