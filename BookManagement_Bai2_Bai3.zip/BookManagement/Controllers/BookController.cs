using BookManagement.Models;
using Microsoft.AspNetCore.Mvc;

namespace BookManagement.Controllers;

public class BookController : Controller
{
    private static readonly List<Book> Books =
    [
        new Book { Id = 1, Name = "Clean Code", Price = 20 },
        new Book { Id = 2, Name = "ASP.NET MVC", Price = 15 },
        new Book { Id = 3, Name = "Design Pattern", Price = 25 }
    ];

    // /Book/Index
    public IActionResult Index()
    {
        return View(Books);
    }

    // /Book/Detail/1
    public IActionResult Detail(int id)
    {
        var book = Books.FirstOrDefault(x => x.Id == id);

        if (book == null)
            return NotFound();

        return View(book);
    }

    // Hiển thị form thêm sách
    [HttpGet]
    public IActionResult Create()
    {
        return View();
    }

    // Xử lý form thêm sách + Validation
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Create(Book book)
    {
        if (!ModelState.IsValid)
        {
            return View(book);
        }

        book.Id = Books.Count == 0 ? 1 : Books.Max(x => x.Id) + 1;
        Books.Add(book);

        ViewBag.Message = "Thêm sách thành công!";
        return View(book);
    }
}
