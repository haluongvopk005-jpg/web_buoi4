BOOK MANAGEMENT - BAI 2 + BAI 3

Yeu cau:
- Visual Studio 2022
- .NET 8 SDK
- ASP.NET Core MVC

Chay:
1. Giai nen file ZIP.
2. Mo BookManagement.sln bang Visual Studio.
3. Neu Visual Studio hoi Restore NuGet packages thi chon Restore.
4. Chay bang F5 hoặc Ctrl+F5.
5. Trang mac dinh: /Book/Index

Chuc nang:
- /Book/Index       : Danh sach sach
- /Book/Detail/1    : Chi tiet sach
- /Book/Create      : Them sach

Validation:
- Ten sach rong -> "Khong duoc de trong"
- Gia <= 0 -> "Gia phai lon hon 0"

Ky thuat:
- Controller + View + Routing
- Data Annotation
- ModelState.IsValid
- Tag Helpers
